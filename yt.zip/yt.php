<?php

	$if_last_octet = [201, 202, 203, 204, 205, 206, 207, 208, 209];


	$state_file = '/tmp/yt.state';

	$today = date('d');


	if( file_exists($state_file) ) {

		$state = file_get_contents($state_file);

		list($day, $index) = explode('/', $state);


		if( $day != $today ) {

			$index += 1;

			if( $index > count($if_last_octet) - 1 ) {

				$index = 0;

			}


			file_put_contents($state_file, $today."/".$index);
		}

	} else {

		$index = 0;

		file_put_contents($state_file, $today."/".$index);

	}


	$ua = array(
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
		'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0'
	);


	$qs = $_SERVER['QUERY_STRING'];

	$url = '';


	switch($qs) {

		case strpos($qs, 'v=') === 0:
			$url = 'https://www.youtube.com/watch?';
			break;

		case strpos($qs, 'video_id=') === 0:
			$url = 'https://www.youtube.com/get_video_info?';
			break;

		case strpos($qs, 'search_query=') === 0:
			$url = 'https://www.youtube.com/results?';
			$ua = array('Mozilla/5.0 (QtEmbedded; Linux) AppleWebKit/534.34 (KHTML, like Gecko) minibrowser Safari/534.34 libwrt stbapp ver: 2 rev: 154');
			break;
	}


	$ch = curl_init($url.$qs);

	curl_setopt($ch, CURLOPT_INTERFACE, '10.20.30.'.$if_last_octet[$index]);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(

		'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		//'Accept-Encoding: gzip, deflate',
		'Accept-Language: ru,en-US;q=0.7,en;q=0.3',
		'Cache-Control: no-cache',
		'Connection: keep-alive',
		'Host: www.youtube.com',
		'Pragma: no-cache',
		'TE: Trailers',
		'Upgrade-Insecure-Requests: 1'
	));

	curl_setopt($ch, CURLOPT_USERAGENT, $ua[rand(0, count($ua)-1)]);

	curl_exec($ch);
?>